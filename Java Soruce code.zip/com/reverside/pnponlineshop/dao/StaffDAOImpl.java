/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.reverside.pnponlineshop.dao;

import com.reverside.pnponlineshop.model.Item;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.util.config.ConfigurationException;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */

@Repository
public class StaffDAOImpl implements StaffDAO {
    SessionFactory sessionFactory;  
    Session session;
    public StaffDAOImpl() {
        try
        {
            Configuration cfg = new Configuration();
            cfg.configure("hibernate.cfg.xml");
            sessionFactory = cfg.buildSessionFactory();
        }catch(ConfigurationException ce){
            
        }
    }
    
    @Override
    public void addItem(Item item)
    {
        try
        {
            session = sessionFactory.openSession();
            session.beginTransaction();
            session.save(item);
            session.getTransaction().commit();
        } catch(Exception ex){
            
        }
    }
    @Override
    public Item getItem(int item)
    {
        try
        {
            session = sessionFactory.openSession();
           
            Criteria criteria = session.createCriteria(Item.class);
            criteria.add(Restrictions.idEq(item));
            return (Item)criteria.list().get(0);
           
        } catch (Exception ex)
        {
            
        }
       return new Item();
    }
    @Override
    public List<Item> getAlltems()
    {
 
        try
        {
            session = sessionFactory.openSession();
            Criteria criteria = session.createCriteria(Item.class);
            return criteria.list();
       
        }catch(Exception ex) {
            
        }
       return null;
    }
}
