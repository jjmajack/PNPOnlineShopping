/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.reverside.pnponlineshop.dao;

import com.reverside.pnponlineshop.model.Customer;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.util.config.ConfigurationException;
import org.springframework.stereotype.Repository;  
import org.springframework.transaction.annotation.Transactional;  
/**
 *
 * @author User
 */

@Repository
public class CustomerDAOImpl implements CustomerDAO {
   
    SessionFactory sessionFactory;  
    Session session;
    public CustomerDAOImpl() {
        try
        {
            Configuration cfg = new Configuration();
            cfg.configure("hibernate.cfg.xml");
            sessionFactory = cfg.buildSessionFactory();
        }catch(ConfigurationException ce){
            
        }
    }
  
  // Save a customer object to the database  
    @Override
    public void createAccount(Customer customer)  
    { 
        
        try
        {
            session = sessionFactory.openSession();
            session.beginTransaction();
            session.save(customer); 
            session.getTransaction().commit();

            System.out.println("ID " + customer.getId());
        } catch(SessionException se){
            
        } finally {
            session.close();
        }
    }
    @Override
    public boolean login(String username, String password)  
    {  
        boolean isValid = false;
        try
        {
            session = sessionFactory.openSession();  
        
            Criteria criteria = session.createCriteria(Customer.class);
            criteria.add(Restrictions.eq("username", username));
            criteria.add(Restrictions.eq("password", password));
            
            isValid = !criteria.list().isEmpty();
        } catch(SessionException se){
            
        } finally {
            session.close();
        }
        return isValid;
    }
}