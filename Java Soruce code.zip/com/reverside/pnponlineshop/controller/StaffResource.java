/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.reverside.pnponlineshop.controller;

import com.reverside.pnponlineshop.dao.StaffDAO;
import com.reverside.pnponlineshop.dao.StaffDAOImpl;
import com.reverside.pnponlineshop.model.Customer;
import com.reverside.pnponlineshop.model.Item;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import jdk.nashorn.internal.objects.annotations.Constructor;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
/**
 * REST Web Service
 *
 * @author User
 */
@Path("Staff")
@CrossOrigin(origins = "http://localhost:8080") //enable the service to be accessed by external request
public class StaffResource {

    StaffDAO staffDAO = new StaffDAOImpl();
    
    @GET
    @Produces("text/plain")
    @Path("/login/{staffno}/{pass}")
    public String login(@PathParam("staffno") String staffNo, @PathParam("pass") String pass)
    {
        return "Hello"; 
    }
    
    @POST
    @Consumes("application/json")
    @Path("/additems")
    public String addItems(@RequestBody String data)
    {
        System.out.println(data);
        try
        {
            Item item = new Item();//(Customer)context.getBean("customer");
            
            JSONParser parser = new JSONParser();
            JSONObject jsonObj = (JSONObject)parser.parse(data);
            
            item.setItemName(jsonObj.get("name").toString());
            item.setDescription(jsonObj.get("descr").toString());
            item.setCategoryID(3); //Integer.parseInt(jsonObj.get("category").toString())
            item.setBrand(jsonObj.get("brand").toString());
            item.setStaffID(1);
            item.setImageUrl("http://localhost:8080/PNPOnlineShop/images/default.png");
            item.setPrice(Double.parseDouble(jsonObj.get("price").toString()));
          
            staffDAO.addItem(item);
            
        }catch(Exception ex){
            return ex.getMessage();
        }
        return "Unknown error";
    }
}
