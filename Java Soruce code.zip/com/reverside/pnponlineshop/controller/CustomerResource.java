/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.reverside.pnponlineshop.controller;

import com.reverside.pnponlineshop.dao.CustomerDAO;
import com.reverside.pnponlineshop.dao.CustomerDAOImpl;
import com.reverside.pnponlineshop.model.Customer;
import java.util.Iterator;
import java.util.List;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.stereotype.Controller;
/**
 * REST Web Service
 *
 * @author User
 */
@Controller
@Path("Customer")
@CrossOrigin(origins = "http://localhost:8080") //enable the service to be accessed by external request
public class CustomerResource {

    ApplicationContext context;
    
    //@Autowired
    CustomerDAO customerDAO = new CustomerDAOImpl();
    public CustomerResource()
    {
        
    }
    @GET
    @Produces("text/plain")
    @Path("/login/{uname}/{pass}")
    public String login(@PathParam("uname") String username,  @PathParam("pass") String password) throws Exception{
        
        try
        {
            if(customerDAO.login(username, password)) return "success";
            else return "Wrong details";        
        } catch(Exception bd)
        {
            return bd.getMessage();
        }
    }
    @POST
    @Consumes("application/json")
    @Path("/register")
    public String createAccount(@RequestBody String data){
           
        try
        {
            //ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
            Customer customer = new Customer();//(Customer)context.getBean("customer");
            
            JSONParser parser = new JSONParser();
            JSONObject jsonObj = (JSONObject)parser.parse(data);
                       
            customer.setUsername(jsonObj.get("uname").toString());
            customer.setPassword(jsonObj.get("password").toString());
            customer.setFirstname(jsonObj.get("firstname").toString());
            customer.setLastname(jsonObj.get("lastname").toString());
            customer.setGender(jsonObj.get("gender").toString());
            customer.setIdno(jsonObj.get("idno").toString());
            customer.setDob(jsonObj.get("dob").toString());
            customer.setContact(jsonObj.get("contact").toString()); 
            customer.setEmail(jsonObj.get("e_mail").toString());
            customer.setAddressID("5");
            
            customerDAO.createAccount(customer);
            return "Successfully registered";
            
        } catch(BeanDefinitionStoreException beanExc)
        {
            return "error...";
            //return ex.getMessage();
        } catch (Exception ex ){
            ex.printStackTrace();
            return "error2...";
        }
    }
}
