/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.reverside.pnponlineshop.model;

import com.reverside.pnponlineshop.model.User;

/**
 *
 * @author User
 */
public class Customer extends User{
  
    private String firstname, lastname;
    private String gender, addressID;
    private String idno, dob;
    private String email, contact;

    public Customer(){}
    
    /*
    public Customer(int id, String username, String firstname, 
            String lastname, String gender, 
            String idno, String dob, String addressID) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.gender = gender;
        this.dob = dob;
        this.idno = idno;
        this.userID = id;
        this.addressID = addressID;
    }*/
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getAddressID() {
        return addressID;
    }
    public void setAddressID(String addressID) {
        this.addressID = addressID;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getIdno() {
        return idno;
    }
    public void setIdno(String idno) {
        this.idno = idno;
    }
    public String getDob() {
        return dob;
    }
    public void setDob(String dob) {
        this.dob = dob;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s", firstname, lastname);
    }
}
